function setup() {
  createCanvas(500, 500);
}

function draw() {
  background("white");
  fill("black")
  rect(100,200,100,200)
   ellipse(150,400,100,50)
  fill("blue")
  ellipse(150,200,100,50)
  fill("rgb(111,111,243)")
  circle(150,250,30)
  fill("rgb(114,221,121)")
  circle(150,300,30)
  circle(175,350,30)
}